import { N, _ } from "../chunks/2.8WKXZUMv.js";
export {
  N as component,
  _ as universal
};
