The icons in this directory are loaded via `gradio.utils.get_icon_path` and
can be used directly in backend code (e.g. to populate icons in components).